# Danzx Shop — Website Panel Pterodactyl

Website statis (HTML/CSS/JS murni, tanpa backend/build tool) untuk jualan slot panel Pterodactyl.

## Struktur folder
```
danzx-shop/
├── index.html
├── assets/
│   ├── style.css
│   └── script.js
└── README.md
```

## Mengubah harga / paket
Edit array `packages` di `assets/script.js` (paling atas file). Setiap paket punya:
- `name` — nama ditampilkan (mis. "2GB")
- `ram`, `disk`, `cpu` — teks spek
- `price30` — harga 30 hari (dipakai untuk hitung harga/hari otomatis)
- `featured` — `true` untuk kasih highlight emas (biasanya paket Unlimited)

Kalau sudah punya harga 7 hari / 90 hari, cari bagian `dur-grid` di `script.js`
(fungsi `renderPackages`) dan ganti teks `Hubungi CS` dengan harga aslinya.

## Ganti nomor WA / username Telegram / QRIS
Tiga baris paling atas `assets/script.js`:
```js
const WA_NUMBER = "6283166896628";
const TG_USERNAME = "Danzx_JBR";
const QRIS_IMAGE = "https://files.catbox.moe/tyr08u.jpg";
```

---

## Deploy ke GitHub Pages (gratis)
1. Buat repository baru di GitHub, misal `danzx-shop`.
2. Upload semua isi folder ini (`index.html`, folder `assets/`, `README.md`) ke repo tersebut.
   - Lewat web: tombol **Add file → Upload files**, drag semua file/folder, commit.
   - Atau lewat terminal:
     ```bash
     git init
     git add .
     git commit -m "Danzx Shop website"
     git branch -M main
     git remote add origin https://github.com/USERNAME/danzx-shop.git
     git push -u origin main
     ```
3. Di repo: **Settings → Pages**.
4. Source pilih **Deploy from a branch**, branch `main`, folder `/ (root)`, klik **Save**.
5. Tunggu 1–2 menit, situs akan aktif di:
   `https://USERNAME.github.io/danzx-shop/`

## Deploy ke VPS (Nginx)
1. Upload folder ke VPS, misal ke `/var/www/danzx-shop`:
   ```bash
   scp -r danzx-shop user@IP_VPS:/var/www/
   ```
2. Install Nginx kalau belum ada:
   ```bash
   sudo apt update && sudo apt install nginx -y
   ```
3. Buat config site baru:
   ```bash
   sudo nano /etc/nginx/sites-available/danzx-shop
   ```
   Isi:
   ```nginx
   server {
       listen 80;
       server_name domainkamu.com www.domainkamu.com;
       root /var/www/danzx-shop;
       index index.html;

       location / {
           try_files $uri $uri/ =404;
       }
   }
   ```
4. Aktifkan:
   ```bash
   sudo ln -s /etc/nginx/sites-available/danzx-shop /etc/nginx/sites-enabled/
   sudo nginx -t
   sudo systemctl restart nginx
   ```
5. (Opsional) Pasang SSL gratis dengan Certbot:
   ```bash
   sudo apt install certbot python3-certbot-nginx -y
   sudo certbot --nginx -d domainkamu.com -d www.domainkamu.com
   ```

Situs ini 100% statis — tidak butuh Node.js, database, atau PHP. Cukup file
HTML/CSS/JS di-serve langsung, jadi ringan dan cepat di VPS sekecil apa pun.
