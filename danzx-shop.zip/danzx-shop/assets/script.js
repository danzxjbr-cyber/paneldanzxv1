// ====== KONFIGURASI TOKO ======
const WA_NUMBER = "6283166896628";
const TG_USERNAME = "Danzx_JBR";
const QRIS_IMAGE = "https://files.catbox.moe/tyr08u.jpg";

// Harga di bawah adalah harga 30 hari (sesuai harga awal Danzx Shop).
// Kolom 7H & 90H belum ada harganya -> tampil "Hubungi CS" sampai diisi manual.
const packages = [
  { name: "2GB",       ram: "2.0GB", disk: "2.0GB", cpu: "90%",  price30: 2000,  featured: false },
  { name: "4GB",       ram: "4.0GB", disk: "4.0GB", cpu: "130%", price30: 4000,  featured: false },
  { name: "6GB",       ram: "6.0GB", disk: "6.0GB", cpu: "160%", price30: 6000,  featured: false },
  { name: "8GB",       ram: "8.0GB", disk: "8.0GB", cpu: "190%", price30: 8000,  featured: false },
  { name: "10GB",      ram: "10.0GB",disk: "10.0GB",cpu: "220%", price30: 10000, featured: false },
  { name: "UNLIMITED", ram: "Unlim", disk: "Unlim", cpu: "∞",    price30: 15000, featured: true  },
];

const fmt = n => "Rp" + n.toLocaleString("id-ID");

function renderPackages(){
  const grid = document.getElementById("pkg-list");
  grid.innerHTML = packages.map(pkg => {
    const daily = Math.round(pkg.price30 / 30);
    return `
    <div class="pkg-card ${pkg.featured ? "featured" : ""}">
      <div class="badges">
        <span class="badge">🔒 PRIVATE</span>
        <span class="badge legal">🛡️ 100% LEGAL</span>
      </div>
      <div class="pkg-title">PANEL PRIVATE <span class="unit">${pkg.name}</span></div>

      <div class="spec-grid">
        <div class="spec-box"><div class="val">${pkg.ram}</div><div class="lbl">RAM</div></div>
        <div class="spec-box"><div class="val">${pkg.disk}</div><div class="lbl">Disk</div></div>
        <div class="spec-box"><div class="val">${pkg.cpu}</div><div class="lbl">CPU</div></div>
        <div class="spec-box"><div class="val">∞</div><div class="lbl">Garansi</div></div>
      </div>

      <div class="dur-grid">
        <div class="dur-box locked"><div class="dlabel">7H</div><div class="dprice">Hubungi CS</div></div>
        <div class="dur-box"><div class="dlabel">30H</div><div class="dprice">${fmt(pkg.price30)}</div></div>
        <div class="dur-box locked"><div class="dlabel">90H</div><div class="dprice">Hubungi CS</div></div>
      </div>

      <div class="price-row">
        <div class="pinfo">
          <div class="pmain">${fmt(daily)}/hari</div>
          <div class="psub">Min. 1 hari &middot; default 30 hari</div>
        </div>
        <button class="order-btn" onclick="openCheckout('${pkg.name}', ${pkg.price30})">Order →</button>
      </div>
    </div>`;
  }).join("");
}

function openCheckout(name, price30){
  document.getElementById("sumName").textContent = "Panel Private " + name + " · 30 Hari";
  document.getElementById("sumPrice").textContent = fmt(price30);
  const msg = `Halo Danzx Shop, saya mau order Panel Private ${name} (30 hari) seharga ${fmt(price30)}. Berikut bukti pembayaran QRIS saya.`;
  document.getElementById("waConfirm").href = `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(msg)}`;
  document.getElementById("checkoutOverlay").classList.add("open");
}

function closeCheckout(){
  document.getElementById("checkoutOverlay").classList.remove("open");
}

function toggleCsMenu(){
  document.getElementById("csMenu").classList.toggle("open");
}

document.addEventListener("DOMContentLoaded", () => {
  renderPackages();

  document.getElementById("qrisImg").src = QRIS_IMAGE;
  document.getElementById("waLink").href = `https://wa.me/${WA_NUMBER}`;
  document.getElementById("tgLink").href = `https://t.me/${TG_USERNAME}`;
  document.getElementById("waLink2").href = `https://wa.me/${WA_NUMBER}`;
  document.getElementById("tgLink2").href = `https://t.me/${TG_USERNAME}`;
  document.getElementById("tgConfirm").href = `https://t.me/${TG_USERNAME}`;

  document.getElementById("modalClose").addEventListener("click", closeCheckout);
  document.getElementById("checkoutOverlay").addEventListener("click", (e) => {
    if (e.target.id === "checkoutOverlay") closeCheckout();
  });

  document.addEventListener("click", (e) => {
    const menu = document.getElementById("csMenu");
    const btn = document.getElementById("csBtn");
    if (!menu.contains(e.target) && !btn.contains(e.target)) {
      menu.classList.remove("open");
    }
  });
});
